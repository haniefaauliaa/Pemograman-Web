function exe(){
    let user, pass;
    user = document.getElementById("user")
    pass = document.getElementById("pass")

    key ={
        username : "admin",
        password : "admin"
    }

    if (user.value == "" || pass.value == ""){
        alert("Data Tidak Ada Yang Boleh Kosong");
    }
    else if (user.value == key.username && pass.value == key.password){
        alert("Login Sukses")
        window.location.href="./landing-page.html";
    } else {
        alert("Login Gagal")
        user.value = "";
        pass.value = "";
    }
}

function reg(){
    let agree, nama, email, regpass, regret;
    nama = document.getElementById("name");
    email = document.getElementById("email");
    regpass = document.getElementById("regpas");
    regret = document.getElementById("regret");
    agree = document.getElementById("agreeTerms");

    if (nama.value == "" || email.value == "" || regpass.value == "" || regret.value == ""){
        alert("Data Tidak Ada Yang Boleh Kosong");
    } else {
        alert("Data anda sudah terdaftar..")
        window.location.href="./login.html";
    }
}
